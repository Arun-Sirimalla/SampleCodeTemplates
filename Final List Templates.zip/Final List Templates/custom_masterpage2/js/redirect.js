﻿<script type="text/javascript">
    function preloadFunc()
    {
       // window.location.replace("https://wigov.sharepoint.com/sites/dot-dev/intranet1/intranet3");
    }
    window.onpaint = preloadFunc();
</script>
