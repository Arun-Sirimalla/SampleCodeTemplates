﻿// For Pre-loader
function showPage() {
    document.getElementById("loader").style.display = "none";
    document.getElementById("mainDivContent").style.display = "block";
}


function retrieveEventsListItems() {
    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Events');
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="True"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collEventsListItem = oList.getItems(camlQuery);
    clientContext.load(collEventsListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededEvents), Function.createDelegate(this, this.onQueryFailed));}

function onQuerySucceededEvents(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collEventsListItem.getEnumerator();
    var i = 0;
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        eventDate = oListItem.get_item('EventDate') == null ? "" : oListItem.get_item('EventDate').toLocaleDateString("en-US");
        description = oListItem.get_item('description');
        url = oListItem.get_item('URL') == null ? "#" : oListItem.get_item('URL').get_url();
        listItemInfo += '<li photo="' + oListItem.get_item('photo') + '" item="' + oListItem.get_id() + '">' +
            '<div  class="float-right"> ' + oListItem.get_item('Title') + '</div>' +'<div style="color:#bbbbbb;font-size: small;     margin-top: 6px;">' + eventDate + '</div>'+
            '<p>' + description + '</p> <a target="_blank" class="more" href="' + url + '">Read more</a>' +
            '</li>';


        i++;
    }
    $('#timeline').html(listItemInfo);
    $('#timeline li').click(function () {
        $('#timeline li').removeClass("active")
        $(this).addClass("active");
        var photo = $(this).attr('photo');
        $("#event-img").html("<img src='" + photo + "' width='100%' height='250px' style='margin-left:10px;margin-bottom:35px;'/>" +
            '<div class="text-block"><h4 style="padding-left: 20px;">' + $(this).find(".float-right").html() + '</h4><p style="padding-left: 20px;">' + $(this).find("p").html() + '</p>  </div>');

    });

    $('#timeline li:first').trigger('click')
    showPage();
}

/*Start Alerts*/
function retrieveAlertsListItems() {
    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Alerts');
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collAlertsListItem = oList.getItems(camlQuery);

    clientContext.load(collAlertsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededAlerts), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededAlerts(sender, args) {
    var listItemInfo = '';
    var listItemEnumerator = collAlertsListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();

        // update for alerts
        listItemInfo += '<div class="col-sm-12"><div class="alert alert-primary">'
                        + '<strong>' + oListItem.get_item('Title') + '</strong><span class="alert-Nolink">' + oListItem.get_item('Description') + '</span>'
                  + '</div> </div>';


        // listItemInfo += '<div class="ticker-item"><a target="_blank" href="' + oListItem.get_item('Title') + '">' + oListItem.get_item('Description') + '</a></div>';


    }
    $('#alerts').html(listItemInfo);

}
/*End Alerts*/


function onQueryFailed(sender, args) {
    showPage();

}

$(document).ready(function () {
    $(".main-title").hide();

    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        retrieveAlertsListItems();
        retrieveEventsListItems();
    });
})