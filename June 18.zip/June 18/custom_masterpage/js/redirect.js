﻿<script type="text/javascript">
    function preloadFunc()
    {
        window.location.replace("https://wigov.sharepoint.com/sites/dot/home/SitePages/Home.aspx");
    }
    window.onpaint = preloadFunc();
</script>
