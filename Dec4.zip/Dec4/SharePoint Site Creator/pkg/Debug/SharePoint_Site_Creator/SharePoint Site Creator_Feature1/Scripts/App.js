﻿
var web;
var currentcontext;
var hostcontext;
var hostUrl;
var parentWeb;
var statusId;


//
// Starting point...
//
$(document).ready(function () {
    initializePeoplePicker('peoplePickerDiv');
    $("#btnValParentWeb").click(ValidateParentButtonOnClick);
    $("#txtParentWebUrl").focusin(function () {
        $("#validationMessage").empty();
        $("#ddlSiteTemplate").empty();
    });
    $("#btnListTemplates").click(ListTemplatesButtonOnClick);
    
    //$("#btnCreateSite").click(createSiteButtonOnClick);
    $("#btnCancel").click(cancelSiteCreation);
    $("input[name=txtSiteTitle]").bind("cut copy paste", function (e) {
        e.preventDefault();
    });

    // Do not allow restricted characters in Site Title which is used to name site.
    $("#txtSiteTitle").keypress(function (e) {
        if (/^[\[\]=;,'@~#%&*{}\:<>?\/\+\\|"_.]*$/.test(String.fromCharCode(e.keyCode)) == true) {
            return false;
        }
    });

    // Do not allow restricted characters in Site Title which is used to name site.
    $("#txtSubwebName").keypress(function (e) {
        if (/^[_~#%&*{}\:<>?\/\+\\|, ]*$/.test(String.fromCharCode(e.keyCode)) == true) {
            return false;
        }
    });

    $("#txtSubwebName").bind({
        paste: function () {
            setTimeout(function () {
                var s = $("#txtSubwebName").val();
                var str = s.replace(/[_~#%&*{}\:<>?\/\+\\|, ]/g, '').toLowerCase();
                $("#txtSubwebName").val(str);
                if (s != str) {
                    $("#substitutionMsg").fadeIn("fast");
                    setTimeout(function () { $("#substitutionMsg").fadeOut("slow") }, 5000);
                }
            }, 100)
        },
        drop: function () {
            setTimeout(function () {
                var s = $("#txtSubwebName").val();
                var str = s.replace(/[_~#%&*{}\:<>?\/\+\\|, ]/g, '').toLowerCase();
                $("#txtSubwebName").val(str);
                if (s != str) {
                    $("#substitutionMsg").fadeIn("fast");
                    setTimeout(function () { $("#substitutionMsg").fadeOut("slow") }, 5000);
                }
            }, 100)
        }
    })


    $("#txtSiteTitle").focus();
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', sharePointReady);
});

function sharePointReady() {
    hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    $("#txtParentWebUrl").val(hostUrl);

    currentcontext = new SP.ClientContext.get_current();
    hostcontext = new SP.AppContextSite(currentcontext, hostUrl);
}

function ListTemplatesButtonOnClick() {
    getSiteTemplates();
}

// Render and initialize the client-side People Picker.
function initializePeoplePicker(peoplePickerElementId) {

    // Create a schema to store picker properties, and set the properties.
    var schema = {};
    schema['PrincipalAccountType'] = 'User';
    schema['SearchPrincipalSource'] = 15;
    schema['ResolvePrincipalSource'] = 15;
    schema['AllowMultipleValues'] = false;
    schema['MaximumEntitySuggestions'] = 50;
    schema['Width'] = '280px';

    // Render and initialize the picker. 
    // Pass the ID of the DOM element that contains the picker, an array of initial
    // PickerEntity objects to set the picker value, and a schema that defines
    // picker properties.
    this.SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);
}


function getSiteTemplates() {
    var siteListsMsg = '';
    var templateCollection;
    var deferred = $.Deferred();

    ValidateParentSiteUrl(deferred);

    deferred.done(function () {
        templateCollection = parentWeb.getAvailableWebTemplates(1033, false);
        currentcontext.load(templateCollection);
        currentcontext.executeQueryAsync(GetTemplatesSuccess, GetTemplatesFail);
    });

    function GetTemplatesSuccess(sender, args) {
        $("#ddlSiteTemplate").empty();
        var olistEnum = templateCollection.getEnumerator();
        while (olistEnum.moveNext()) {
            var oListItem = olistEnum.get_current();
            if (oListItem.get_isHidden() == false && oListItem.get_displayCategory() == null) {
                var title = oListItem.get_title();
                var name = oListItem.get_name();
                $("#ddlSiteTemplate").append("<option value=\'" + name + "\'>" + title + "</option>");
            }
        }
        $("#ddlSiteTemplate")[0].selectedIndex = 0;
    }

    function GetTemplatesFail(sender, args) {
        statusId = SP.UI.Status.addStatus('Failed to get templates. Error:' + args.get_message());
        SP.UI.Status.setStatusPriColor(statusId, 'red');
        setTimeout(SP.UI.Status.removeStatus(statusId), 5000);
    }
}


// Validate parent web url
function ValidateParentButtonOnClick() {
    var deferred = $.Deferred();
    ValidateParentSiteUrl(deferred);
}

function ValidateParentSiteUrl(def) {
    var parentUrl = $("#txtParentWebUrl").val();

    if (parentUrl[parentUrl.length - 1] == '/') {
        parentUrl = parentUrl.slice(0, -1);
        $("#txtParentWebUrl").val(parentUrl);
    }

    var parentContext = new SP.AppContextSite(currentcontext, parentUrl);
    parentWeb = parentContext.get_web();
    currentcontext.load(parentWeb);
    currentcontext.executeQueryAsync(onGetParentWebSuccess, onGetParentWebFail);

    function onGetParentWebSuccess() {
        var subWeb;
        if (parentUrl.toLowerCase() != parentWeb.get_url().toLowerCase()) {
            ValidationFailed();
        }
        else {
            $("#validationMessage").html("<span class='successMessage'>Parent Site URL validation succeeded.</span>")
            def.resolve();
            return;
        }
    }

    function onGetParentWebFail(sender, args) {
        ValidationFailed();
    }

    function ValidationFailed() {
        $("#validationMessage").html("<span class='errorMessage'>Parent Site URL validation failed.<br/>Site does not exist or you do not have rights.</span>")
        def.reject();
    }
}

function GetSiteOwner() {
    var peoplePicker = this.SPClientPeoplePicker.SPClientPeoplePickerDict.peoplePickerDiv_TopSpan;
    return peoplePicker.GetAllUserKeys();
}

function IsOwnerNameResolved() {
    var peoplePicker = this.SPClientPeoplePicker.SPClientPeoplePickerDict.peoplePickerDiv_TopSpan;
    var users = peoplePicker.GetAllUserInfo();
    if (users == null)
        return false;

    if (users[0]["IsResolved"] == true)
        return true;
    else
        return false;
}

function createSiteButtonOnClick() {
    SP.UI.Status.removeAllStatus(true);
    $("#txtSubwebName").val($("#txtSubwebName").val().toLowerCase());
    var siteName = $("#txtSiteTitle").val();
    var description = $("#txtDescription").val();
    var division = $("#ddDivision").val();
    var siteOwner = GetSiteOwner();
    var parentUrl = $("#txtParentWebUrl").val();
    var subwebUrl = $("#txtSubwebName").val();
    var siteTemplateId = $("#ddlSiteTemplate").val();
    var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    if (siteName == '' || division == '' || parentUrl == '' || subwebUrl == '' || siteTemplateId == 'null' || siteTemplateId == '') {
        $('#s4-workspace').animate({ scrollTop: 0 }, 'slow');
        statusId = SP.UI.Status.addStatus("Missing Information:", "Please enter information into all required fields.");
        SP.UI.Status.setStatusPriColor(statusId, 'red');
        return;
    }
    if (siteOwner != '') {
        if (!IsOwnerNameResolved()) {
            $('#s4-workspace').animate({ scrollTop: 0 }, 'slow');
            statusId = SP.UI.Status.addStatus("Site Owner is not valid.  Please correct. ");
            SP.UI.Status.setStatusPriColor(statusId, 'red');
            return;
        }
    }
    var args = {
        siteName: siteName,
        description: description,
        division: division,
        siteOwner: siteOwner,
        parentUrl: parentUrl,
        subwebUrl: subwebUrl,
        siteTemplateId: siteTemplateId,
        hostUrl: hostUrl
    }


    //Using a generic object.
    var options = {
        width: 400,
        height: 600,
        showClose: false,
        args: args,
        dialogReturnValueCallback: Function.createDelegate(null, dialogReturn),
        url: "createDialog.aspx"
    };

    SP.UI.ModalDialog.showModalDialog(options);
}

function cancelSiteCreation() {
    window.close();
}

function dialogReturn() {
    location.reload();
}

//
// Miscellaneous helper functions.
//

function getQueryStringParameter(paramToRetrieve) {
    var params =
    document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}

function disableForm() {
    $("#txtSiteTitle").attr("disabled", "disabled");
    $("#txtDescription").attr("disabled", "disabled");
    $("#txtParentWebUrl").attr("disabled", "disabled");
    $("#txtSubwebName").attr("disabled", "disabled");
    $("#ddlSiteTemplate").attr("disabled", "disabled");
    $("#btnValParentWeb").attr("disabled", "disabled");
    $("#btnListTemplates").attr("disabled", "disabled");
    $("#btnCreateSite").attr("disabled", "disabled");
    //$("#btnCancel").attr("disabled", "disabled");
}

function enableForm() {
    $("#txtSiteTitle").removeAttr("disabled");
    $("#txtDescription").removeAttr("disabled");
    $("#txtParentWebUrl").removeAttr("disabled");
    $("#txtSubwebName").removeAttr("disabled");
    $("#ddlSiteTemplate").removeAttr("disabled");
    $("#btnValParentWeb").removeAttr("disabled");
    $("#btnListTemplates").removeAttr("disabled");
    $("#btnCreateSite").removeAttr("disabled");
    //$("#btnCancel").removeAttr("disabled");
}

function clearForm() {
    $("#siteManager").find(':input').each(function () {
        switch (this.type) {
            case 'password':
            case 'text':
            case 'textarea':
            case 'file':
            case 'select-one':
            case 'select-multiple':
                $(this).val('');
                break;
            case 'checkbox':
            case 'radio':
                this.checked = false;
        }
    });
}

