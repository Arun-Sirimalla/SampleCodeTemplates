﻿var customMasterUrl;
var siteName;
var description;
var division;
var siteOwner;
var siteOwnerId;
var siteTemplateId;
var parentUrl;
var subwebUrl;
var currentcontext;
var hostUrl;
var site;
var newSiteUrl;
var associateGroups = '';
var welcomePage;
var SiteContactFieldName = "ContactLoginName";
var siteDirectoryWebUrl = 'https://i77.sharepoint.com/sites/ilab/';
var errorOccurred = false;
var ownerGroupName = '';

SP.SOD.executeFunc('sp.js', 'SP.ClientContext'function () {
    retrieveCurrentListProperties();
})


$(document).ready(function () {
    $("#btnClose").click(closeOnClick);
    $("#s4-ribbonrow").hide();

    //SP.SOD.execute('SP.UI.ModalDialog.showModalDialog');

    //var args = SP.UI.ModalDialog.get_childDialog().get_args();
    var args = window.frameElement.dialogArgs;

    siteName = args.siteName;
    description = args.description;
    division = args.division;
    siteOwner = args.siteOwner;
    siteTemplateId = args.siteTemplateId;
    parentUrl = args.parentUrl;
    subwebUrl = args.subwebUrl;
    hostUrl = args.hostUrl;

    currentcontext = new SP.ClientContext.get_current();
    var parentcontext = new SP.AppContextSite(currentcontext, parentUrl);
    web = parentcontext.get_web();
    currentcontext.load(web);
    currentcontext.executeQueryAsync(onGetWebSuccess, onGetWebFail);

    function onGetWebSuccess() {
        customMasterUrl = web.get_customMasterUrl();
        SP.SOD.executeOrDelayUntilScriptLoaded(startProcess, "sp.js");
    }

    function onGetWebFail(sender, args) {
        $("#progressWrap").hide();
        $("#progressLog").append("<div style='color:red;'>Error - " + args.get_message() + "</div>");
        $("#btnClose").show();
    }

});

function startProcess() {
    $("#progressLog").empty().append("<div class='sxsTxt'>Site provisioning process started.</div>");
    var spWebPromise = NAPP.Automation.Site.createSite();
    $.when(spWebPromise) // begin promise chaining
        .then(function (spWeb) { return NAPP.Automation.Navigation.setNavigationDefaults(spWeb); })
        .then(function (spWeb) { return NAPP.Automation.Permissions.setPermissions(spWeb); })    // This step must come before 'createSiteGroups' 
                                                                                                 // because it removes all permissions.
        .then(function (spWeb) { return createSiteGroups(spWeb); })
        .then(function (spWeb) { return NAPP.Automation.SiteOwnerToPermission.addSiteOwnerToPermissionGroup(spWeb); })
        .then(function (spWeb) { return NAPP.Automation.MasterPage.setMasterPage(spWeb); })
        .then(function (spWeb) { return NAPP.Automation.WelcomePage.getWelcomePage(spWeb); })
        .then(function (spWeb) { return NAPP.Automation.QuickLaunch.fixQuickLaunch(spWeb); })
//        .then(function (spWeb) { return NAPP.Automation.SitePagesPermissions.setSitePagesToReadOnly(spWeb); })
        .then(function (spWeb) { return NAPP.Automation.Webparts.setSiteOwnerWebPart(spWeb); })
        .then(function () { return NAPP.Automation.SiteDirectory.addToSiteDirectory(); })
        .done(function () {
            $("#progressWrap").hide();
            $("#progressLog").append("<div class='sxsTxt3'>Site provisioning process complete.</div>");
            $("#btnClose").show();
        })
        .fail(function (sender, args) {
            $("#progressWrap").hide();
            $("#progressLog").append("<div class='errorMessage'>Error: " + args.get_message() + "</div>");
            $("#progressLog").append("<div class='errorMessage'>Site provisioning process completed with error.</div>");
            $("#btnClose").show();
        });


}

function closeOnClick() {
    SP.UI.ModalDialog.get_childDialog().close();
}

//
// Create site
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.Site = function () {
    var createSite = function () {
        return $.Deferred(function (def) {
            $("#progressLog").empty().append("<div>Creating new site...<br/><span style='color: Red'>This may take a few minutes. Please do not close the browser.</span></div>");  

            var appContextSite = new SP.AppContextSite(currentcontext, parentUrl);
            this.web2 = appContextSite.get_web();

            var WCI = new SP.WebCreationInformation();
            WCI.set_webTemplate(siteTemplateId);
            WCI.set_description(description);
            WCI.set_title(siteName);
            WCI.set_url(subwebUrl);
            WCI.set_language(1033);
            WCI.set_useSamePermissionsAsParentSite("false");
            this.newSite = this.web2.get_webs().add(WCI);
            currentcontext.load(this.newSite);
            currentcontext.executeQueryAsync(
                Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>" + siteName + " site created.</div>");
                    newSiteUrl = this.newSite.get_url();
                    $("#newSiteLink").append("<div class='sxsTxt'>New site URL: <a href='" + newSiteUrl + "' target='_blank'>" + newSiteUrl + "</a></div>");
                    def.resolve(this.newSite);
                }),
                Function.createDelegate(this, function (sender, args) {
                    def.reject(sender, args);
                    errorOccurred = true;
                })
            );
        });
    };
    return { createSite: createSite };
}();

//
// Set the default navigation.
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.Navigation = function () {
    var setNavigationDefaults = function (spWeb) {
        return $.Deferred(function (def) {

            var nav = spWeb.get_navigation();
            nav.set_useShared(true);
            spWeb.update();
            currentcontext.executeQueryAsync(
                Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>Top navigation refreshed.</div>");
                    def.resolve(spWeb);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Top navigation update failed. " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                })
            );
        })
    };
    return { setNavigationDefaults: setNavigationDefaults };
}();




//
// Add site to Site Directory list.
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.SiteDirectory = function () {
    var addToSiteDirectory = function (spWeb) {
        return $.Deferred(function (def) {
            $("#progressLog").append("<div>Add new site to site directory.</div>");
            var sdWebContext = new SP.AppContextSite(currentcontext, siteDirectoryWebUrl);
            sdWeb = sdWebContext.get_web();
            currentcontext.load(sdWeb);
            currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                if (siteOwner == '') {
                    WriteToDirectory(sdWeb, null);
                    return;
                }
                var user = sdWeb.ensureUser(siteOwner);
                currentcontext.load(user);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    var userValue = new SP.FieldUserValue();
                    userValue.set_lookupId(user.get_id());
                    WriteToDirectory(sdWeb, userValue);
                }),
              Function.createDelegate(this, function (sender, args) {
                  $("#progressLog").append("<div class='errorMessage'>Adding to site directory failed (user). " + args.get_message() + "</div>");
                  errorOccurred = true;
                  def.resolve(spWeb);
              })
              );
            }),
              Function.createDelegate(this, function (sender, args) {
                  $("#progressLog").append("<div class='errorMessage'>Adding to site directory failed (sdWeb). " + args.get_message() + "</div>");
                  errorOccurred = true;
                  def.resolve(spWeb);
              })
            );
            
            function WriteToDirectory(sdWeb, ownerValue) {
                var sdList = sdWeb.get_lists().getByTitle('Site Directory');
                var itemCreateInfo = new SP.ListItemCreationInformation();
                var sdListItem = sdList.addItem(itemCreateInfo);
                sdListItem.set_item('Title', siteName);
                sdListItem.set_item('URL', newSiteUrl);
                sdListItem.set_item('Division', division);
                sdListItem.set_item('Description', description);
                if (ownerValue != null) {
                    sdListItem.set_item('Owner', ownerValue);
                }
                sdListItem.update();
                currentcontext.load(sdListItem);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    $("#progressLog").append("<div>Add new site to site directory complete.</div>");
                    def.resolve(spWeb);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Adding to site directory failed (sdListItem). " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }))

            }

        });
    };
    return { addToSiteDirectory:addToSiteDirectory }
}();


//
// Assign the site's masterpage
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.MasterPage = function () {
    var setMasterPage = function (spWeb) {
        return $.Deferred(function (def) {

            var masterPageFile = '';
            if (customMasterUrl.lastIndexOf("/") > -1) {
                masterPageFile = customMasterUrl.substring(customMasterUrl.lastIndexOf("/"));
            }
            spWeb.set_customMasterUrl(customMasterUrl);
            spWeb.set_masterUrl(customMasterUrl);
            spWeb.update();
            currentcontext.executeQueryAsync(
                Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>MasterPage updated to: " + masterPageFile + "</div>");
                    def.resolve(spWeb);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Updating MasterPage failed. " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                })
            );
        })
    };
    return { setMasterPage: setMasterPage };
}();


//
// Get the Welcome page for the site.
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.WelcomePage = function () {
    var getWelcomePage = function (spWeb) {
        return $.Deferred(function (def) {

            welcomePage = '';
            var rootFolder = spWeb.get_rootFolder();
            currentcontext.load(rootFolder);
            currentcontext.executeQueryAsync(
                Function.createDelegate(this, function () {
                    welcomePage = rootFolder.get_welcomePage();
                    def.resolve(spWeb);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Getting welcome page failed (getWelcomePage). " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                })
            );
        })
    };
    return { getWelcomePage: getWelcomePage };
}();


//
// Edit the QuickLaunch of the site.
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.QuickLaunch = function () {
    var fixQuickLaunch = function (spWeb) {
        return $.Deferred(function (def) {
            $("#progressLog").append("<div class='sxsTxt'>Updating quick launch menu.</div>");
            var quickLaunch = spWeb.get_navigation().get_quickLaunch();
            currentcontext.load(quickLaunch);
            currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                AddNewNode(quickLaunch);
            }),
            Function.createDelegate(this, function (sender, args) {
                $("#progressLog").append("<div class='errorMessage'>Error: " + args.get_message() + "</div>");
                errorOccurred = true;
                def.resolve(spWeb);
            }));

            function AddNewNode(quickLaunch) {

                var nodeEnum = quickLaunch.getEnumerator();
                while (nodeEnum.moveNext()) {
                    var node = nodeEnum.get_current();
                    if (node.get_title().toLowerCase() == "home" || node.get_title().toLowerCase() == "site resources") {
                        if (welcomePage.length > 0) {
                            node.set_url(welcomePage);
                        }
                        else {
                            node.set_url('');
                        }
                        node.update();
                    }
                }
                currentcontext.load(quickLaunch);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='sxsTxt'>Updating quick launch menu complete.</div>");
                    def.resolve(spWeb);

                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Updating quick launch menu failed: " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }));
            }
        })
    };
    return { fixQuickLaunch: fixQuickLaunch };
}();

//
// Set the default permissions (GACC_DOT_SharePoint_E3_Users, All DTSD Staff)
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.Permissions = function () {
    var setPermissions = function (spWeb) {
        return $.Deferred(function (def) {
            $("#progressLog").append("<div class='sxsTxt'>Setting default permissions.</div>");
            var assignments = spWeb.get_roleAssignments();

            currentcontext.load(assignments);
            currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                deletePermissions(assignments);
            }), Function.createDelegate(this, function (sender, args) {
                $("#progressLog").append("<div class='errorMessage'>Setting default permissions failed (get_roleAssignments): " + args.get_message() + "</div>");
                errorOccurred = true;
                def.resolve(spWeb);
            }));

            function deletePermissions(assignments) {
                while (assignments.get_count() > 0) {
                    assignments.get_item(0).deleteObject();
                }
                currentcontext.load(assignments);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    assignPermissions(assignments);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Setting default permissions failed (deletePermissions): " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }));
            }
            function assignPermissions(assignments) {
                //var spUserEveryone = spWeb.ensureUser("GACC_DOT_SharePoint_E3_Users");
                var spUserEveryone = spWeb.ensureUser("admin@i77.onmicrosoft.com");
                debugger;
                var rdRead = spWeb.get_roleDefinitions().getByName("Read");
                var collRead = SP.RoleDefinitionBindingCollection.newObject(currentcontext);
                collRead.add(rdRead);

                var roleAssignmentRead = assignments.add(spUserEveryone, collRead);
                currentcontext.load(assignments);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>Setting default permissions complete.</div>");
                    def.resolve(spWeb);
                }), Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Setting default permissions failed (assignPermissions): " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }));
            }
        })
    };
    return { setPermissions: setPermissions };
}();

//
// Set permission on the Site Pages document library.
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.SitePagesPermissions = function () {
    var setSitePagesToReadOnly = function (spWeb) {
        return $.Deferred(function (def) {
            $("#progressLog").append("<div class='sxsTxt'>Setting Site Pages document library permissions.</div>");
            var dlSitePages = spWeb.get_lists().getByTitle("Site Pages");
            dlSitePages.breakRoleInheritance(false, false);
            var assignments = dlSitePages.get_roleAssignments();

            currentcontext.load(assignments);
            currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                deletePermissions(assignments)
            }), Function.createDelegate(this, function (sender, args) {
                $("#progressLog").append("<div class='errorMessage'>Setting Site Pages document library permissions failed (get_roleAssignments): " + args.get_message() + "</div>");
                errorOccurred = true;
                def.resolve(spWeb);
            }));

            function deletePermissions(assignments) {
                while (assignments.get_count() > 0) {
                    assignments.get_item(0).deleteObject();
                }
                currentcontext.load(assignments);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    setDefaultPermissions(assignments);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Setting Site Pages document library permissions failed (deletePermissions): " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }));
            }

            function setDefaultPermissions(dlSitePages) {
              //  var spUserEveryone = spWeb.ensureUser("GACC_DOT_SharePoint_E3_Users");
                var spUserEveryone = spWeb.ensureUser("admin@i77.onmicrosoft.com");
                debugger;

                var rdRead = spWeb.get_roleDefinitions().getByName("Read");
                var collRead = SP.RoleDefinitionBindingCollection.newObject(currentcontext);
                collRead.add(rdRead);

                var roleAssignmentRead = assignments.add(spUserEveryone, collRead);
                currentcontext.load(assignments);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>Setting Site Pages document library permissions complete.</div>");
                    def.resolve(spWeb);
                }), Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Setting Site Pages document library permissions failed (deletePermissions): " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }));
            }
        })
    };
    return { setSitePagesToReadOnly: setSitePagesToReadOnly };
}();


//
// Call to have each SharePoint group created and add links to quick launch in Site Settings.
//
function createSiteGroups(spWeb) {
    debugger;
    return $.Deferred(function (def) {
        $.when(
            $("#progressLog").append("<div class='sxsTxt2'>Creating groups...</div>"),
            NAPP.Automation.Groups.createGroups(spWeb, siteName + " Visitors", "Read", "Visitors"),
            NAPP.Automation.Groups.createGroups(spWeb, siteName + " Members", "Contribute", "Members"),
            //NAPP.Automation.Groups.createGroups(spWeb, siteName + " Owners", "Site Owner (WisDOT)", "Owners")
            NAPP.Automation.Groups.createGroups(spWeb, siteName + " Owners", "Full Control", "Owners")
        )
        .done(function () {
            setAssociateGroupsProp(spWeb);
            if(ownerGroupName != '') {
                setGroupOwnership(spWeb);
            }
            $("#progressLog").append("<div class='sxsTxt2'>Creating groups complete.</div>");
        })
        .fail(function (sender, args) {
            $("#progressLog").append("<div class='errorMessage'>Creating groups failed (createSiteGroups): " + args.get_message() + "</div>");
            errorOccurred = true;
            def.resolve(spWeb);
        });

        function setAssociateGroupsProp(spWeb) {
            var allProps = spWeb.get_allProperties();
            currentcontext.load(allProps);
            currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                allProps.set_item("vti_associategroups", associateGroups);
                spWeb.update();
                currentcontext.load(allProps);
                currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                    def.resolve(spWeb);
                }), Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='errorMessage'>Creating groups failed (setAssociateGroupsProp): " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                }));
            }));
        }
    });
}

//
// Start process to set ownership of SP Groups
//

function setGroupOwnership(spWeb) {
    return $.Deferred(function (def) {
        $.when(
            $("#progressLog").append("<div class='sxsTxt2'>Setting group ownership.</div>"),
            NAPP.Automation.Ownership.setOwnership(spWeb, siteName + " Visitors"),
            NAPP.Automation.Ownership.setOwnership(spWeb, siteName + " Members"),
            NAPP.Automation.Ownership.setOwnership(spWeb, siteName + " Owners")
        )
        .done(function () {
            $("#progressLog").append("<div class='sxsTxt2'>Setting group ownership complete.</div>");
        })
        .fail(function (sender, args) {
            $("#progressLog").append("<div class='errorMessage'>Setting group ownership failed (createSiteGroups): " + args.get_message() + "</div>");
            errorOccurred = true;
            def.resolve(spWeb);
        });


    });
}

//
// Set ownership of SP Group
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.Ownership = function () {
    var setOwnership = function (spWeb, groupName) {
        return $.Deferred(function (def) {
            this.groupCollection = spWeb.get_siteGroups();
            this.group = this.groupCollection.getByName(groupName);
            this.group.set_owner(this.groupCollection.getByName(ownerGroupName));
            this.group.update();
            currentcontext.executeQueryAsync(
                Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>" + groupName + " ownership assigned.</div>");
                    def.resolve(spWeb);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Setting group ownership failed: " + groupName + " - " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                })
            )
        })
    };
    return { setOwnership: setOwnership };
}();


//
// Create a SharePoint group.
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.Groups = function () {
    var createGroups = function (spWeb, groupName, permissionLevel, assocGroup) {
        return $.Deferred(function (def) {
            debugger;
            this.context = SP.ClientContext.get_current();
            this.groupCollection = spWeb.get_siteGroups();

            var permissionGroup = new SP.GroupCreationInformation();
            permissionGroup.set_title(groupName);
            permissionGroup.set_description("");
            var oPermissionsGroup = this.groupCollection.add(permissionGroup);

            var rollDef = spWeb.get_roleDefinitions().getByName(permissionLevel);
            var collBind = SP.RoleDefinitionBindingCollection.newObject(this.context);
            collBind.add(rollDef);

            var assignments = spWeb.get_roleAssignments();
            var roleAssignment = assignments.add(oPermissionsGroup, collBind);

            if (assocGroup == 'Owners') {
                spWeb.set_associatedOwnerGroup(oPermissionsGroup);
                ownerGroupName = groupName;
            } else if (assocGroup == 'Members') {
                spWeb.set_associatedMemberGroup(oPermissionsGroup);
            } else if (assocGroup == 'Visitors') {
                spWeb.set_associatedVisitorGroup(oPermissionsGroup);
            }


            this.context.load(oPermissionsGroup);
            this.context.executeQueryAsync(
                Function.createDelegate(this, function () {
                    $("#progressLog").append("<div class='sxsTxt'>" + groupName + " group created.</div>");
                    (associateGroups == '') ? associateGroups = oPermissionsGroup.get_id() : associateGroups += ';' + oPermissionsGroup.get_id();
                    def.resolve(spWeb);
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Creating group " + groupName + " failed. " + args.get_message() + "</div>");
                    errorOccurred = true;
                    def.resolve(spWeb);
                })
            );
        })
    };
    return { createGroups: createGroups };
}();


//
// Add site owner to permission group
// x

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.SiteOwnerToPermission = function () {
    var addSiteOwnerToPermissionGroup = function (spWeb) {
        return $.Deferred(function (def) {
            if (siteOwner == '') {
                def.resolve(spWeb);
                return;
            }
            $("#progressLog").append("<div class='sxsTxt'>Set site owner permissions.</div>");
            var siteOwnersGroupName = siteName + " Owners";
            var groupColl = spWeb.get_siteGroups();
            ownersGroup = groupColl.getByName(siteOwnersGroupName);
            var user = spWeb.ensureUser(siteOwner);
            var userColl = ownersGroup.get_users();
            var oUser = userColl.addUser(user);
            currentcontext.load(oUser);
            currentcontext.load(userColl);
            currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                $("#progressLog").append("<div class='sxsTxt2'>Set site owner permissions complete.</div>");
                def.resolve(spWeb);
            }), Function.createDelegate(this, function (sender, args) {
                $("#progressLog").append("<div class='errorMessage'>Set site owner permissions failed: " + args.get_message() + "</div>");
                errorOccurred = true;
                def.resolve(spWeb);
            }));
        });
    }
    return { addSiteOwnerToPermissionGroup: addSiteOwnerToPermissionGroup };
}();

//
// Add site owner to Site Owner web part
//

var NAPP = window.NAPP || {};
NAPP.Automation = NAPP.Automation || {};

NAPP.Automation.Webparts = function () {
    var setSiteOwnerWebPart = function (spWeb) {
        return $.Deferred(function (def) {
            var serverRelativeUrl = spWeb.get_serverRelativeUrl() + '/SitePages/Home.aspx';
            oFile = spWeb.getFileByServerRelativeUrl(serverRelativeUrl);
            limitedWebPartManager = oFile.getLimitedWebPartManager(SP.WebParts.PersonalizationScope.shared);
            var collWebPart = limitedWebPartManager.get_webParts();
            currentcontext.load(collWebPart);
            currentcontext.executeQueryAsync(
                Function.createDelegate(this, function () {
                    var enumWebPartColl = collWebPart.getEnumerator();
                    while (enumWebPartColl.moveNext()) {
                        var webPartDef = enumWebPartColl.get_current();
                        var wp = webPartDef.get_webPart();
                        (function (wp, webPartDef) {
                            currentcontext.load(wp);
                            currentcontext.executeQueryAsync(function () {
                                if (wp.get_title().toLowerCase() == 'site owner') {
                                    var webPartProperties = wp.get_properties();
                                    currentcontext.load(webPartProperties);
                                    currentcontext.executeQueryAsync(function () {
                                        webPartProperties.set_item(SiteContactFieldName, siteOwner);
                                        webPartDef.saveWebPartChanges();
                                        currentcontext.executeQueryAsync(Function.createDelegate(this, function () {
                                            $("#progressLog").append("<div class='sxsTxt2'>Set site owner web part property complete.</div>");
                                            def.resolve();
                                        }),
                                        Function.createDelegate(this, function (sender, args) {
                                            $("#progressLog").append("<div class='errorMessage'>Set site owner web part property failed (webPartProperties): " + args.get_message() + "</div>");
                                            def.resolve();
                                        }))
                                    },
                                    Function.createDelegate(this, function () {
                                        $("#progressLog").append("<div class='errorMessage'>Set site owner web part property failed (wp): " + args.get_message() + "</div>");
                                        def.resolve();
                                    }));
                                }
                            },
                            Function.createDelegate(this, function () {
                                $("#progressLog").append("<div class='errorMessage'>Set site owner web part property failed (collWebPart): " + args.get_message() + "</div>");
                                def.resolve();
                            }));
                        })(wp, webPartDef);
                    }
                }),
                Function.createDelegate(this, function (sender, args) {
                    $("#progressLog").append("<div class='errorMessage'>Set site owner web part property failed (collWebPart): " + args.get_message() + "</div>");
                    def.resolve();
                })
            );
        });
    };
    return { setSiteOwnerWebPart: setSiteOwnerWebPart };
}();


//
// Miscellaneous helper functions.
//

function getQueryStringParameter(paramToRetrieve) {
    var params =
    document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}
