 window.addEventListener('load', function () {
                    SetFullScreenMode(true);
