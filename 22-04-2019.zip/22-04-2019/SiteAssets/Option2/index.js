﻿// For Pre-loader
function showPage() {
      document.getElementById("loader").style.display = "none";
      document.getElementById("mainDivContent").style.display = "block";
    }


function retrieveEventsListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Events');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collEventsListItem = oList.getItems(camlQuery);

    clientContext.load(collEventsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededEvents), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededEvents(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collEventsListItem.getEnumerator();
    var i = 0;
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        eventDate= oListItem.get_item('EventDate')==null ? "":oListItem.get_item('EventDate').toLocaleDateString("en-US");
        description=oListItem.get_item('description');
       // if (description.length > 200) {
         //   description=description.substr(0, description.lastIndexOf(' ', 200)) + '...';
          //}
        listItemInfo += '<li photo="' + oListItem.get_item('photo') + '" item="' + oListItem.get_id() + '">'
                            + '<div  class="float-right"> ' + oListItem.get_item('Title') + '<span style="padding-left: 15px;">' + eventDate + '</span></div>'
                           // + '<p>' + description + '</p> <a target="_blank" class="more" href="Eventdetail.aspx?id='+oListItem.get_id()+'">Read more</a>'
                           + '<p>' + description + '</p> <a target="_blank" class="more" href="'+oListItem.get_item('URL')+'">Read more</a>'

                           
                        + '</li>';
        //if (i == 0) {
       //     $("#event-img").html("<img src='" + oListItem.get_item('photo') + "' width='100%' height='500px'/>");
       // }

        i++;
    }
    $('#timeline').html(listItemInfo);
    $('#timeline li').click(function () {
	$('#timeline li').removeClass("active")
    $(this).addClass("active");
        var photo = $(this).attr('photo');
        $("#event-img").html("<img src='" + photo + "' width='100%' height='500px'/>"+
        '<div class="text-block"><h4 style="padding-left: 20px;">'+$(this).find(".float-right").html()+'</h4><p style="padding-left: 20px;">'+$(this).find("p").html()+'</p>  </div>');
       // $("p").animate({ "font-size": "16px", "line-height": "20px" });
    });
    
    $('#timeline li:first').trigger('click')
}
/*Start RSS*/
function retrieveRSSListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('RSS Feed');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collRSSListItem = oList.getItems(camlQuery);

    clientContext.load(collRSSListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededRSS), Function.createDelegate(this, this.onQueryFailed));

}
function onQuerySucceededRSS(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collRSSListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '<li item="' + oListItem.get_id() + '">'
                            + '<div  class="rss-title">' + oListItem.get_item('Title') + '</div>'
                            + '<p>' + oListItem.get_item('description') + '</p>'
                        + '</li>';


    }
    $('#rss ul').html(listItemInfo);
}
/*end RSS*/
/*Start News*/
function retrievenewsListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('news');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>4</RowLimit></View>');
    this.collnewsListItem = oList.getItems(camlQuery);

    clientContext.load(collnewsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceedednews), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceedednews(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collnewsListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '<div class="col-md-3 HomeNews" item="' + oListItem.get_id() + '">'
                            + '<div class="rss-title">' + oListItem.get_item('Title') + '</div>'
                            + '<p>' + oListItem.get_item('description') + '</p>'
                        + '</div>';

    }
    $('#news').html(listItemInfo);
}
/*End News*/
/*Start Info Links*/
function retrieveInfoLinksListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Info Links');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collInfoLinksListItem = oList.getItems(camlQuery);

    clientContext.load(collInfoLinksListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededInfoLinks), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededInfoLinks(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collInfoLinksListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '<li item="' + oListItem.get_id() + '">'
                            + '<a href="' + oListItem.get_item('URL') + '" >' + oListItem.get_item('Title') + '</div>'
                        + '</li>';


    }
    $('#InfoLinks ul').html(listItemInfo);
}
/*End Info Links*/
/*Start announcements*/
function retrieveAnnouncementsListItems(lookupId) {
    //debugger;
    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Announcements');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name='section' LookupId='True' /><Value Type='Lookup'>" + lookupId + "</Value></Eq></Where></Query> <ViewFields><FieldRef Name='Title' /><FieldRef Name='Body' /><FieldRef Name='Photo' /><FieldRef Name='section' /><FieldRef Name='ID' /><FieldRef Name='date' /></ViewFields></View>");
    this.collAnnouncementsListItem = oList.getItems(camlQuery);

    clientContext.load(collAnnouncementsListItem, 'Include(Title,section,ID,Photo,Body,date)');

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededAnnouncements), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededAnnouncements(sender, args) {
    var listItemInfo = '';
    //debugger;
    var i = 0;
    var listItemEnumerator = collAnnouncementsListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        if (i == 0) {
            listItemInfo += '<div item="' + oListItem.get_item('ID') + '" class="item active">';

        }
        else {
            listItemInfo += '<div item="' + oListItem.get_item('ID') + '" class="item">';
        }

        listItemInfo += '<div class="row">'
                        + '<div class="col-md-8">'
                            + '<img src="' + oListItem.get_item('Photo') + '" alt="Image" />'
                          + '</div>'
                            + '<div class="col-md-4">'
                            + '<h4>' + oListItem.get_item('Title') + '</h4>'
                                + '<div class="announce-date">' + oListItem.get_item('date') + '</div>'
                                + '<p>' + $(oListItem.get_item('Body')).text() + '</p>'
                                    + '<a href="/sites/dot/Pages/single.aspx?id=' + oListItem.get_item('ID') + '" class="more" target="_blank">Read More</a>'
                                + '</div>'
                            + '</div>'
                        + '</div>';
        i++;

    }
    $('#carousel-inner').html(listItemInfo);
    $('.btn-vertical-slider').on('click', function () {

        if ($(this).attr('data-slide') == 'next') {
            $('#announcements').carousel('next');

        }
        if ($(this).attr('data-slide') == 'prev') {
            $('#announcements').carousel('prev');
        }

    });
}
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
/*End announcements*/

/*Start Alerts*/
function retrieveAlertsListItems() {
    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Alerts');
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collAlertsListItem = oList.getItems(camlQuery);

    clientContext.load(collAlertsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededAlerts), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededAlerts(sender, args) {

     var listItemInfo = '';
    var listItemEnumerator = collAlertsListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();

        if (oListItem.get_item('URL')) {
            listItemInfo += '<div class="alert alert-' + oListItem.get_item('Alert_x0020_Type').toLowerCase() + '">'
                            + '<strong>' + oListItem.get_item('Title') + '</strong>    <a target="_blank" href="' + oListItem.get_item('URL') + '" class="alert-link">' + oListItem.get_item('Description')+ '</a>'
                      + '</div>';
        }
        else {
            listItemInfo += '<div class="alert alert-' + oListItem.get_item('Alert_x0020_Type').toLowerCase() + '">'
                            + '<strong>' + oListItem.get_item('Title') + '</strong><span class="alert-Nolink">' +oListItem.get_item('Description')+'</span>'
                      + '</div>';
        }

        // listItemInfo += '<div class="ticker-item"><a target="_blank" href="' + oListItem.get_item('Title') + '">' + oListItem.get_item('Description') + '</a></div>';


    }
    $('#alerts').html(listItemInfo);
}
/*End Alerts*/
/*Start Divisions*/
function retrieveDivisionsListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Divisions');

    var camlQuery = new SP.CamlQuery();
    this.collDivisionsListItem = oList.getItems(camlQuery);

    clientContext.load(collDivisionsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededDivisions), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededDivisions(sender, args) {

    var listItemInfo = '';
    var listItemEnumerator = collDivisionsListItem.getEnumerator();
    var i = 0;
    while (listItemEnumerator.moveNext()) {

        var oListItem = listItemEnumerator.get_current();
        if (i == 0) {
            //listItemInfo += '<option value="' + oListItem.get_id() + '" selected>' + oListItem.get_item('Title') + '</option>';
           listItemInfo += '<a  value="' + oListItem.get_id() + '">' + oListItem.get_item('Title') + '</a>'
            retrieveSectionsByIdListItems(oListItem.get_id());

        }
        else {
            //listItemInfo += '<option value="' + oListItem.get_id() + '">' + oListItem.get_item('Title') + '</option>';
            listItemInfo += '<a value="' + oListItem.get_id() + '">' + oListItem.get_item('Title') + '</a>'

        }
        i++;
    }
    $('#myDropdown').html(listItemInfo);
    $('#myDropdown a').click(function () {
        var selectedValue = $(this).attr('value');
        
        retrieveSectionsByIdListItems(selectedValue);

    });
    // $('#Divisions select').html(listItemInfo);
    // $('#Divisions select').change(function () {
    //     var selectedValue = $(this).val();
    //     retrieveSectionsByIdListItems(selectedValue);

    // });
}
/*End Divisions*/
//Sections
function retrieveSectionsByIdListItems(lookupId) {
    var clientContextSections = new SP.ClientContext.get_current();;
    var oList = clientContextSections.get_web().get_lists().getByTitle('Sections');
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name='Division' LookupId='True' /><Value Type='Lookup'>" + lookupId + "</Value></Eq></Where></Query> <ViewFields><FieldRef Name='Title' /><FieldRef Name='Division' /><FieldRef Name='ID' /></ViewFields></View>");
    this.collListItemSections = oList.getItems(camlQuery, 'Include(Title,Division,ID)');
    clientContextSections.load(collListItemSections);
    clientContextSections.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededSections), Function.createDelegate(this, this.onQueryFailed));
}
function onQuerySucceededSections(sender, args) {
    //debugger;
    var SectionsHTML = '';
    var listItemEnumerator = collListItemSections.getEnumerator();
    var i = 0;
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        var oListItemID = oListItem.get_item('ID');

        var oListItemTitle = oListItem.get_item('Title');
        if (oListItemTitle == null) {
            oListItemTitle = '';
        }
        if (i == 0) {
            retrieveAnnouncementsListItems(oListItemID);
            SectionsHTML += '<div class="col-md-3 HomeNews" style="background:#8e5a37" item="' + oListItemID + '">'
                           + '<div class="sec-title"  style="color:#fff" >' + oListItemTitle + '</div>'
                     + '</div>';

        }

        else {
            SectionsHTML += '<div class="col-md-3 HomeNews" item="' + oListItemID + '">'
                           + '<div class="sec-title">' + oListItemTitle + '</div>'
                     + '</div>';
        }
       


       

        i++;

    }

    $('#news').html(SectionsHTML);
    $('.sec-title').click(function () {
    	$('.sec-title').each(function () {
            $(this).css('color', '#000');
        });
        $('.HomeNews').each(function () {
            $(this).css('background', 'transparent');
        });
        $(this).closest('.HomeNews').css('background', '#8e5a37');
        $(this).css('color', '#fff');

        console.log($(this).closest('.HomeNews').attr('item'));
        retrieveAnnouncementsListItems($(this).closest('.HomeNews').attr('item'));
    });

}
/*End Sections*/
function onQueryFailed(sender, args) {

    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
$(document).ready(function () {

    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        retrieveEventsListItems();
        retrieveRSSListItems();
        retrieveInfoLinksListItems();
        retrieveAlertsListItems();
        retrieveDivisionsListItems();
        		showPage();

    });

	$("#facebookFeed").click(function(){
	feedHtml="<h4>FACEBOOK FEED</h4>";
	feedHtml+='<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fpeafowlitsolution%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1404078729737985" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>';
	$("#rss").html(feedHtml);
	});
	
	$("#twitterFeed").click(function(){
	feedHtml="<h4>TWITTER FEED</h4>";
	feedHtml+='<div style="height: 300px;overflow-y: scroll;"><a class="twitter-timeline" href="https://twitter.com/peafowlit?ref_src=twsrc%5Etfw">Tweets by peafowlit</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></div>';
	$("#rss").html(feedHtml);
	});
    $(".nav-tabs a").click(function(){
        $(this).tab('show');
      });
      

})


