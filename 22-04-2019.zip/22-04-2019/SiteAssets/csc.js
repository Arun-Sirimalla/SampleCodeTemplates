﻿var table = null;
$(document).ready(function () {

    ExecuteOrDelayUntilScriptLoaded(retrieveproductDefinationListItems, "sp.js");

    



});


var siteUrl = '/sites/dot/';

/*Retrieve*/
function retrieveproductDefinationListItems() {

    debugger;
    var clientContextPD = SP.ClientContext.get_current();
    var oList = clientContextPD.get_web().get_lists().getByTitle('Service Directory');
    var camlQuery = new SP.CamlQuery();
    //camlQuery.set_viewXml('<View><RowLimit>100</RowLimit></View>');
    this.collListItem = oList.getItems(camlQuery);
    clientContextPD.load(collListItem);
    clientContextPD.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededDefinationList), Function.createDelegate(this, this.onQueryFailed));
}

function onQuerySucceededDefinationList(sender, args) {
    debugger;
    var PDHTML = '';
    var listItemEnumerator = collListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {

        var oListItem = listItemEnumerator.get_current();
        var oListItemID = oListItem.get_item('ID');
        var oListItemPostal_x0020_Code = oListItem.get_item('Postal_x0020_Code');
        var oListItemPostal_x0020_CodeURL = "#";
        if (oListItemPostal_x0020_Code == null) {
            oListItemPostal_x0020_Code = '';
        }
        else{
        	oListItemPostal_x0020_Code = oListItem.get_item('Postal_x0020_Code').get_description();
        	oListItemPostal_x0020_CodeURL = oListItem.get_item('Postal_x0020_Code').get_url();
        }

        var oListItemProgram = oListItem.get_item('Program');
        if (oListItemProgram == null) {
            oListItemProgram = '';
        }

        var oListItemCCAC = oListItem.get_item('CCAC');
        if (oListItemCCAC == null) {
            oListItemCCAC = '';
        }
        var oListItemCluster_x0020_and_x0020_NCT_x002 = oListItem.get_item('Cluster_x0020_and_x0020_NCT_x002');
        if (oListItemCluster_x0020_and_x0020_NCT_x002 == null) {
            oListItemCluster_x0020_and_x0020_NCT_x002 = '';
        }
        var Coordinator_x002f_Sub = oListItem.get_item('Coordinator_x002f_Sub');
        if (Coordinator_x002f_Sub == null) {
            Coordinator_x002f_Sub = '';
        }

        var oListItemWork_x0020_Group_x002f_GC = oListItem.get_item('Work_x0020_Group_x002f_GC');
        if (oListItemWork_x0020_Group_x002f_GC == null) {
            oListItemWork_x0020_Group_x002f_GC = '';
        }
        var oListItemWork_x0020_Group_x0020_Team = oListItem.get_item('Work_x0020_Group_x0020_Team');
        if (oListItemWork_x0020_Group_x0020_Team == null) {
            oListItemWork_x0020_Group_x0020_Team = '';
        }


        var oListItemSupervisor = oListItem.get_item('Supervisor');
        if (oListItemSupervisor == null) {
            oListItemSupervisor = '';
        }

        var oListItemRegional_x0020_Manager = oListItem.get_item('Regional_x0020_Manager');
        if (oListItemRegional_x0020_Manager == null) {
            oListItemRegional_x0020_Manager = '';
        }
        var oListItemCluster_x0020_and_x0020_NCT_x0020 = oListItem.get_item('Cluster_x0020_and_x0020_NCT_x0020');
        if (oListItemCluster_x0020_and_x0020_NCT_x0020 == null) {
            oListItemCluster_x0020_and_x0020_NCT_x0020 = '';
        }
        var oListItemSub_x0020_Contractors = oListItem.get_item('Sub_x0020_Contractors');
        if (oListItemSub_x0020_Contractors == null) {
            oListItemSub_x0020_Contractors = '';
        }



        PDHTML += '<tr id=' + oListItemID + '>'
                     + '<td class="ID">' + oListItemID + '</td>'
                     + '<td class="Program">' + oListItemProgram + '</td>'
                     + '<td class="Postal_x0020_Code"><a href="'+oListItemPostal_x0020_CodeURL+'">' + oListItemPostal_x0020_Code + '</a></td>'

                      /*Start CCAC*/
                     + '<td class="CCAC">' + oListItemCCAC + '</td>'
                    /*End CCAC*/
                    + '<td class="Sub_x0020_Contractors">' + oListItemSub_x0020_Contractors + '</td>'
                    + '<td class="Cluster_x0020_and_x0020_NCT_x002">' + oListItemCluster_x0020_and_x0020_NCT_x002 + '</td>'
                    + '<td class="Coordinator_x002f_Sub">' + Coordinator_x002f_Sub + '</td>'
                    + '<td class="Work_x0020_Group_x002f_GC">' + oListItemWork_x0020_Group_x002f_GC + '</td>'
                    + '<td class="Work_x0020_Group_x0020_Team">' + oListItemWork_x0020_Group_x0020_Team + '</td>'
                    + '<td class="Supervisor">' + oListItemSupervisor + '</td>'
                    + '<td class="Regional_x0020_Manager">' + oListItemRegional_x0020_Manager + '</td>'
                    + '<td class="Cluster_x0020_and_x0020_NCT_x0020">' + oListItemCluster_x0020_and_x0020_NCT_x0020 + '</td>'
            + '</tr>';

    }
    $('#PDTableId').html(PDHTML);
    $('#loadingSp').hide();
    $('#PDTable thead tr').clone(true).appendTo('#PDTable thead');
    $('#PDTable thead tr:eq(1) th').each(function (i) {
        var title = $(this).text();
        $(this).html('<input type="text" placeholder="Search" />');

        $('input', this).on('keyup change', function () {
            if (table.column(i).search() !== this.value) {
                table
                    .column(i)
                    .search(this.value)
                    .draw();
            }
        });
    });

    table = $('#PDTable').DataTable({
        orderCellsTop: true,
        fixedHeader: true
    });



}
/*create New Item*/
