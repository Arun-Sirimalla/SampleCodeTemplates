$(document).ready(function () {
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        runCode(getQueryVariable('id'));
    });


})

function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}

/*Start announcements*/

   function runCode(itemId) {
     var clientContext = new SP.ClientContext(); 
     var targetList = clientContext.get_web().get_lists().getByTitle('Events');
     this.targetListItem = targetList.getItemById(itemId);
     clientContext.load(targetListItem);
     clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded), Function.createDelegate(this, this.onQueryFailed));
   }

   function onQuerySucceeded() {
   
    var listItemInfo = '<div class="row">'
                         + '<div class="col-md-12">'
                            + '<img src="' + targetListItem.get_item('photo') + '" alt="Image" style="width:100%;height:350px"/>'
                         + '</div>'
                         + '<div class="col-md-12">'
                            + '<h4>' + targetListItem.get_item('Title') + '</h4>'
                                + '<div class="announce-date">' + targetListItem.get_item('EventDate') + '</div>'
                                    + '<p>' + targetListItem.get_item('description') + '</p>'
                                + '</div>'
                         + '</div>'
                        +'</div>';

          $("#singleArticle").html(listItemInfo);
 }

   function onQueryFailed(sender, args) {
     console.log('Request failed. \nError: ' + args.get_message() + '\nStackTrace: ' + args.get_stackTrace());
   }
/*End announcements*/