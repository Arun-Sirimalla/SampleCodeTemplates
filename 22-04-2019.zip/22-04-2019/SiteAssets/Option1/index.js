﻿// For Pre-loader
function showPage() {
      document.getElementById("loader").style.display = "none";
      document.getElementById("mainDivContent").style.display = "block";
    }


function retrieveEventsListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Events');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collEventsListItem = oList.getItems(camlQuery);

    clientContext.load(collEventsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededEvents), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededEvents(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collEventsListItem.getEnumerator();
    var i = 0;
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        eventDate = oListItem.get_item('EventDate') == null ? "" : oListItem.get_item('EventDate').toLocaleDateString("en-US");
        listItemInfo += '<li photo="' + oListItem.get_item('photo') + '" item="' + oListItem.get_id() + '">'
                            + '<div  class="float-right"> ' + oListItem.get_item('Title') + '<span style="padding-left: 15px;">' + eventDate + '</span></div>'
                            + '<p>' + oListItem.get_item('description') + '</p>'
                        + '</li>';
        if (i == 0) {
            $("#event-img").html("<img src='" + oListItem.get_item('photo') + "' width='100%' height='500px'/>");
        }

        i++;
    }
    $('#timeline').html(listItemInfo);
    $('#timeline li').click(function () {
        $('#timeline li').removeClass("active")
        $(this).addClass("active");
        var photo = $(this).attr('photo');
        $("#event-img").html("<img src='" + photo + "' width='100%' height='500px'/>" +
        '<div class="text-block"><h4 style="padding-left: 20px;">' + $(this).find(".float-right").html() + '</h4><p style="padding-left: 20px;">' + $(this).find("p").html() + '</p>  </div>');
        // $("p").animate({ "font-size": "16px", "line-height": "20px" });
    });
}
/*Start RSS*/
function retrieveRSSListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('RSS Feed');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collRSSListItem = oList.getItems(camlQuery);

    clientContext.load(collRSSListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededRSS), Function.createDelegate(this, this.onQueryFailed));

}
function onQuerySucceededRSS(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collRSSListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '<li item="' + oListItem.get_id() + '">'
                            + '<div  class="rss-title">' + oListItem.get_item('Title') + '</div>'
                            + '<p>' + oListItem.get_item('description') + '</p>'
                        + '</li>';


    }
    $('#rss ul').html(listItemInfo);
}
/*end RSS*/
/*Start News*/
function retrievenewsListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('news');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>4</RowLimit></View>');
    this.collnewsListItem = oList.getItems(camlQuery);

    clientContext.load(collnewsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceedednews), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceedednews(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collnewsListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '<div class="col-md-4 HomeNews" item="' + oListItem.get_id() + '">'
                            + '<div class="rss-title">' + oListItem.get_item('Title') + '</div>'
                            + '<p>' + oListItem.get_item('description') + '</p>'
                        + '</div>';

    }
    $('#news').html(listItemInfo);
}
/*End News*/
/*Start Info Links*/
function retrieveInfoLinksListItems() {

    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Info Links');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collInfoLinksListItem = oList.getItems(camlQuery);

    clientContext.load(collInfoLinksListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededInfoLinks), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededInfoLinks(sender, args) {

    var listItemInfo = '';

    var listItemEnumerator = collInfoLinksListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '<li item="' + oListItem.get_id() + '">'
                            + '<a href="' + oListItem.get_item('URL') + '" >' + oListItem.get_item('Title') + '</div>'
                        + '</li>';


    }
    $('#InfoLinks ul').html(listItemInfo);
}

/*Start announcements*/
function retrieveAnnouncementsListItems(choice) {
    
    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Announcements');
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name='section'/><Value Type='Choice'>" + choice + "</Value></Eq></Where></Query><ViewFields><FieldRef Name='Title' /><FieldRef Name='Body' /><FieldRef Name='Photo' /><FieldRef Name='section' /><FieldRef Name='ID' /><FieldRef Name='date' /><FieldRef Name='URL' /></ViewFields></View>");
    this.collAnnouncementsListItem = oList.getItems(camlQuery);
    clientContext.load(collAnnouncementsListItem, 'Include(Title,section,ID,Photo,Body,date,URL)');

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededAnnouncements), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededAnnouncements(sender, args) {
    var listItemInfo = '';

    var i = 0;
    var listItemEnumerator = collAnnouncementsListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        if (i == 0) {
            listItemInfo += '<div item="' + oListItem.get_item('ID') + '" class="item active">';

        }
        else {
            listItemInfo += '<div item="' + oListItem.get_item('ID') + '" class="item">';
        }
        announcementDate = oListItem.get_item('date') == null ? "" : moment(oListItem.get_item('date')).format('dddd, DD MMMM, YYYY');
        listItemInfo += '<div class="row">'
                        + '<div class="col-md-8">'
                            + '<img src="' + oListItem.get_item('Photo') + '" alt="Image" />'
                          + '</div>'
                            + '<div class="col-md-4">'
                            + '<h4>' + oListItem.get_item('Title') + '</h4>'
                                + '<div class="announce-date">' + announcementDate  + '</div>'
                                + '<p>' + $(oListItem.get_item('Body')).text() + '</p>'
                                    + '<a href="' + oListItem.get_item('URL').get_url() + '" class="more" target="_blank">Read More</a>'
                                + '</div>'
                            + '</div>'
                        + '</div>';
        i++;

    }
    $('#carousel-inner').html(listItemInfo);
    $('.btn-vertical-slider').on('click', function () {

        if ($(this).attr('data-slide') == 'next') {
            $('#announcements').carousel('next');

        }
        if ($(this).attr('data-slide') == 'prev') {
            $('#announcements').carousel('prev');
        }

    });
}
/*End announcements*/
function getChoiceFieldValues() {
    // Setup context and load current web
    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    // Get task list
    var taskList = web.get_lists().getByTitle("Announcements");

    // Get Priority field (choice field)
    this.priorityField = context.castTo(taskList.get_fields().getByInternalNameOrTitle("section"),
                                       SP.FieldChoice);

    // Load the field
    context.load(priorityField);

    // Call server
    context.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededGetChoiceFieldValues),
                              Function.createDelegate(this, this.onQueryFailed));

}


function onQuerySucceededGetChoiceFieldValues(sender, args) {
    var SectionsHTML = '';
    var choices = priorityField.get_choices();
    var next=0;
    for (var i = 0; i < choices.length; i++) {
        if (i == 0) {
            retrieveAnnouncementsListItems(choices[i]);
            SectionsHTML += '<div class="col-md-4 HomeNews" style="background:#444444" itemId="'+i+'" item="' + choices[i] + '">'
                            + '<div class="sec-title"  style="color:#fff" >' + choices[i]+ '</div>'
                        + '</div>';
            next =i+ 1;

        }

        else {
            SectionsHTML += '<div class="col-md-4 HomeNews" itemId="'+i+'" item="' + choices[i] + '">'
                            + '<div class="sec-title">' + choices[i] + '</div>'
                        + '</div>';
        }

    }
    $('#news').html(SectionsHTML);
    $('#news').find("[itemid='" + next + "']").find('.sec-title').css('border', '0px');
    $('.sec-title').click(function () {
        $('.sec-title').each(function () {
            $(this).css('color', '#000');
            $(this).css('border-left', '4px solid #444444');
        });

        $('.HomeNews').each(function () {
            $(this).css('background', 'transparent');
        });


        $(this).closest('.HomeNews').css('background', '#444444');
        $(this).css('color', '#fff');

        var itemId = $(this).closest('.HomeNews').attr('itemId');
        console.log(itemId);
        var NextItemId = parseInt(itemId) + 1;
        $('#news').find("[itemid='" + NextItemId + "']").find('.sec-title').css('border', '0px');
        console.log(NextItemId);
        retrieveAnnouncementsListItems($(this).closest('.HomeNews').attr('item'));
    });

}

/*Start Alerts*/
function retrieveAlertsListItems() {
    var clientContext = SP.ClientContext.get_current();;
    var oList = clientContext.get_web().get_lists().getByTitle('Alerts');
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query><RowLimit>3</RowLimit></View>');
    this.collAlertsListItem = oList.getItems(camlQuery);

    clientContext.load(collAlertsListItem);

    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededAlerts), Function.createDelegate(this, this.onQueryFailed));

}

function onQuerySucceededAlerts(sender, args) {

    var listItemInfo = '';
    var listItemEnumerator = collAlertsListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();

        if (oListItem.get_item('URL')) {
            listItemInfo += '<div class="alert alert-' + oListItem.get_item('Alert_x0020_Type').toLowerCase() + '">'
                            + '<strong>' + oListItem.get_item('Title') + '</strong>    <a target="_blank" href="' + oListItem.get_item('URL') + '" class="alert-link">' + oListItem.get_item('Description')+ '</a>'
                      + '</div>';
        }
        else {
            listItemInfo += '<div class="alert alert-' + oListItem.get_item('Alert_x0020_Type').toLowerCase() + '">'
                            + '<strong>' + oListItem.get_item('Title') + '</strong>' +oListItem.get_item('Description')
                      + '</div>';
        }

        // listItemInfo += '<div class="ticker-item"><a target="_blank" href="' + oListItem.get_item('Title') + '">' + oListItem.get_item('Description') + '</a></div>';


    }
    $('#alerts').html(listItemInfo);
}
/*End Alerts*/

/*End Sections*/
function onQueryFailed(sender, args) {

    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}


$(document).ready(function () {

    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        retrieveEventsListItems();
        retrieveRSSListItems();
        retrieveInfoLinksListItems();
        retrieveAlertsListItems();
        getChoiceFieldValues();
        showPage();

    });

    $("#facebookFeed").click(function () {
        feedHtml = "<h4>FACEBOOK FEED</h4>";
        feedHtml += '<iframe src="https://www.facebook.com/plugins/page.php?href=http://www.facebook.com/WisDOT%2F&tabs=timeline&width=500&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1404078729737985&target=_top" width="500" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>            ';
        $("#rss").html(feedHtml);
    });

    $("#twitterFeed").click(function () {
        feedHtml = "<h4>TWITTER FEED</h4>";
        feedHtml += '<div style="height: 500px;overflow-y: scroll;"><a class="twitter-timeline" href="https://twitter.com/WisconsinDOT?ref_src=twsrc%5Etfw">Tweets by DOT</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></div>';
        $("#rss").html(feedHtml);
    });

})


