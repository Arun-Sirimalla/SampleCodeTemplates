﻿$(document).ready(function () {
    ExecuteOrDelayUntilScriptLoaded(retrieveListItemsLetterTypes, "sp.js");
});
function retrieveListItemsLetterTypes() {
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle('Articles');
    var camlQuery = new SP.CamlQuery();
    this.collListItemCourses = oList.getItems(camlQuery);
    clientContext.load(collListItemCourses);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededLetterTypes), Function.createDelegate(this, this.onQueryFailed));

}


function onQuerySucceededLetterTypes(sender, args) {
    var listItemInfo = '';
    var listItemEnumerator = collListItemCourses.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
       
        listItemInfo +="<h3>"+oListItem.get_item('Title')+"</h3>"
					    +"<div>"
					    	+"<p>"+ oListItem.get_item('body')+"</p>"
					   +"</div>";
        
    }
    $('#articles').html(listItemInfo);
    $("#articles").accordion({
      collapsible: true
    });

}
