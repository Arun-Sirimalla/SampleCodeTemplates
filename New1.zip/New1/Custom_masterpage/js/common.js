﻿function getItems(url) { 
							// get data from list
    return $.ajax({
		beforeSend: function() {

		},
        url: _spPageContextInfo.webAbsoluteUrl + url,
        type: "GET",
		async: false,
        headers: {
            "accept": "application/json;odata=verbose",
        },
        success: function (data) {
        },
        error: function (error) {
            console.log(JSON.stringify(error));
        }
    });

}
$( document ).ready(function() {  
setPageTitle();
 
  getsiteOwners();
  });

function getsiteOwners()
{
getItems("/_api/web/lists/getbytitle('Pages')/items("+_spPageContextInfo.pageItemId+")?$select=Author/Title,*&$expand=Author").then(function(data){

html='';
owners='';

//$.each(data.d.results, function( index, value ) {
value=data.d;
if(value.Author.Title!="")
{

html+='<span class="icon-box__subtitle"><i class="fa fa-user">  </i> '+value.Author.Title+' </span> <br/>';
owners+='<a href="#"><i class="fa fa fa-user"></i>'+value.Author.Title+'</a>';
}
//});

$("#siteowners").html(html); // Top Footer
$(".footer-siteOwner").append(html.replace("<br/>","")); // bottom footer
})
}


function setPageTitle(){
    // pageTitle
    $("#pageTitle").text(document.title);
}