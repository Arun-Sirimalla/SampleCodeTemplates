﻿var table = null;
$(document).ready(function () {

    ExecuteOrDelayUntilScriptLoaded(retrieveProcessMatrixListItems, "sp.js");


});


var siteUrl = '/CSC/';

/*Retrieve*/
function retrieveProcessMatrixListItems() {

    debugger;
    var clientContextProcessMatrix = SP.ClientContext.get_current();
    var oList = clientContextProcessMatrix.get_web().get_lists().getByTitle('Process Matrix');
    var camlQuery = new SP.CamlQuery();
    this.collListItem = oList.getItems(camlQuery);
    clientContextProcessMatrix.load(collListItem);
    clientContextProcessMatrix.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededProcessMatrixList), Function.createDelegate(this, this.onQueryFailed));
}

function onQuerySucceededProcessMatrixList(sender, args) {
    debugger;
    var ProcessMatrixHTML = '';
    var listItemEnumerator = collListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {







        var oListItem = listItemEnumerator.get_current();
        var oListItemID = oListItem.get_item('ID');
        var oListItemDepartment = oListItem.get_item('Department');
        if (oListItemDepartment == null) {
            oListItemDepartment = '';
        }


        var oListItemCaller = oListItem.get_item('Caller');
        if (oListItemCaller == null) {
            oListItemCaller = '';
        }

        var oListItemCall_x0020_Type = oListItem.get_item('Call_x0020_Type');
        if (oListItemCall_x0020_Type == null) {
            oListItemCall_x0020_Type = '';
        }
        var oListItem_x0038__x003a_30_x002d_4_x003a_3 = oListItem.get_item('_x0038__x003a_30_x002d_4_x003a_3');
        if (oListItem_x0038__x003a_30_x002d_4_x003a_3 == null) {
            oListItem_x0038__x003a_30_x002d_4_x003a_3 = '';
        }
        var After_x0020_Hours_x0020_Procedur = oListItem.get_item('After_x0020_Hours_x0020_Procedur');
        if (After_x0020_Hours_x0020_Procedur == null) {
            After_x0020_Hours_x0020_Procedur = '';
        }

        var oListItemExamples = oListItem.get_item('Examples');
        if (oListItemExamples == null) {
            oListItemExamples = '';
        }
        var oListItemTemplate_x0028_s_x0029_ = oListItem.get_item('Template_x0028_s_x0029_');
        if (oListItemTemplate_x0028_s_x0029_ == null) {
            oListItemTemplate_x0028_s_x0029_ = '';
        }


        ProcessMatrixHTML += '<tr id=' + oListItemID + '>'
                     + '<td class="ID">' + oListItemID + '</td>'
                     + '<td class="Department">' + oListItemDepartment + '</td>'
                     + '<td class="Caller">' + oListItemCaller + '</td>'
                     + '<td class="Call_x0020_Type">' + oListItemCall_x0020_Type + '</td>'
                       // +'<td class="_x0038__x003a_30_x002d_4_x003a_3 more">' + $(oListItem_x0038__x003a_30_x002d_4_x003a_3).text() + '</td>'
                       // + '<td class="After_x0020_Hours_x0020_Procedur more">' + $(After_x0020_Hours_x0020_Procedur).text() + '</td>'
                     + '<td><span style="display:none" class="procedures"><h5>8:30-4:30 Procedure</h5>' + oListItem_x0038__x003a_30_x002d_4_x003a_3 +'<h5>After Hours Procedure</h5>'+ After_x0020_Hours_x0020_Procedur + '</span><a  href="#" class="proceduresLinks"  data-toggle="modal" data-target="#proceduresModal">Show</a></td>'
			       // + '<td class="Examples ">' + $(oListItemExamples).text() + '</td>'
			        + '<td><span style="display:none" class="examples">' + oListItemExamples+ '</span><a  href="#" class="examplesLinks"  data-toggle="modal" data-target="#examplesModal">Show</a></td>'
			        + '<td class="Template_x0028_s_x0029_">' + oListItemTemplate_x0028_s_x0029_ + '</td>'
+ '</tr>';

    }
    $('#ProcessMatrixTableId').html(ProcessMatrixHTML);

    $('.proceduresLinks').click(function () {
        var procedures = $(this).closest('td').find('.procedures').html();
        $('#proceduresModalBody').html(procedures);
    })
     $('.examplesLinks').click(function () {
        var procedures = $(this).closest('td').find('.examples').html();
        $('#examplesModalBody').html(procedures);
    })


    var showChar = 100;
    var ellipsestext = "...";
    var moretext = "more";
    var lesstext = "less";
    $('.more').each(function () {
        var content = $(this).html();

        if (content.length > showChar) {

            var c = content.substr(0, showChar);
            var h = content.substr(showChar - 1, content.length - showChar);

            var html = c + '<span class="moreelipses">' + ellipsestext + '</span><span class="morecontent"><span>' + h + '</span><a href="" class="morelink">' + moretext + '</a></span>';

            $(this).html(html);
        }

    });

    $(".morelink").click(function () {
        if ($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });



    $('#loadingSp').hide();
    $('#ProcessMatrixTable thead tr').clone(true).appendTo('#ProcessMatrixTable thead');
    $('#ProcessMatrixTable thead tr:eq(1) th').each(function (i) {
        var title = $(this).text();
        $(this).html('<input type="text" placeholder="Search" />');

        $('input', this).on('keyup change', function () {
            if (table.column(i).search() !== this.value) {
                table
                    .column(i)
                    .search(this.value)
                    .draw();
            }
        });

        $('input', this).keypress(function (e) {

            if (e.keyCode == 13) {
                $('input', this).click();
                e.preventDefault ? e.preventDefault() : e.returnValue = false;
                return false;
            }
        });

    });

    table = $('#ProcessMatrixTable').DataTable({
        orderCellsTop: true,
        fixedHeader: true,
        "pageLength": 50
    });



}
/*create New Item*/
