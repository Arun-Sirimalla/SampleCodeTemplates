$(document).ready(function () {
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        runCode(getQueryVariable('id'));
    });


})

function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}

/*Start announcements*/

   function runCode(itemId) {
     var clientContext = new SP.ClientContext(); 
     var targetList = clientContext.get_web().get_lists().getByTitle('Events');
     
     var camlQuery = new SP.CamlQuery();
     camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="Created" Ascending="false"></FieldRef></OrderBy></Query></View>');
     this.targetListItem = targetList.getItems(camlQuery);
     clientContext.load(targetListItem);
     clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded), Function.createDelegate(this, this.onQueryFailed));
   }

   function onQuerySucceeded() {
    var listItemEnumerator = targetListItem.getEnumerator();
    while (listItemEnumerator.moveNext()){
        var oListItem = listItemEnumerator.get_current();
        eventDate= oListItem.get_item('EventDate')==null ? "":oListItem.get_item('EventDate').toLocaleDateString("en-US");
    var listItemInfo =  '<div class="col-sm-3"> <a class="card-link" href="Eventdetail.aspx?id='+oListItem.get_id()+'"> </a><div class="card">'
                            + '<img src="' + oListItem.get_item('photo') + '" alt="Image" style="width:100%;height:150px"/>'                        
                         + '<div class="card-wrapper">'
                         + '<div class="card-header">'
                            + '<span class="title">' + oListItem.get_item('Title') + '</span>'
                                + '<span class="pull-right">' + eventDate + '</span>'
                                + '</div>'
                                    + '<p>' + oListItem.get_item('description') + '</p>'
                                + '</div>'
                         + '</div>'                        
                        +'</div>';
                        console.log(listItemInfo)
          $("#eventsSection").append(listItemInfo);

    }
 }

   function onQueryFailed(sender, args) {
     console.log('Request failed. \nError: ' + args.get_message() + '\nStackTrace: ' + args.get_stackTrace());
   }
/*End announcements*/