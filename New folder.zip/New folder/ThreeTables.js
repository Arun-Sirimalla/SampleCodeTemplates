﻿$(document).ready(function () {
    ExecuteOrDelayUntilScriptLoaded(retrieveListItemsTables, "sp.js");
});
function retrieveListItemsTables() {
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle('Tables');
    var camlQuery = new SP.CamlQuery();
    this.collListItemTables = oList.getItems(camlQuery);
    clientContext.load(collListItemTables);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededTables), Function.createDelegate(this, this.onQueryFailed));

}


function onQuerySucceededTables(sender, args) {
    var listItemInfo1 = '';
    var listItemInfo2 = '';
    var listItemInfo3 = '';
    var listItemEnumerator = collListItemTables.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
       
        listItemInfo1 +="<tr><td>"+oListItem.get_item('Title')+"</td></tr>";
        listItemInfo2 +="<tr><td>"+oListItem.get_item('table2')+"</td></tr>";
        listItemInfo3 +="<tr><td>"+oListItem.get_item('table3')+"</td></tr>";


        
    }
    $('#tbl1').html(listItemInfo1);
    $('#tbl2').html(listItemInfo2);
    $('#tbl3').html(listItemInfo3);

  
}
